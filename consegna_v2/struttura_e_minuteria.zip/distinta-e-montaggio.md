# Bormuri: scheletro con supporti, distinta e montaggio

Data: 17/10/2026. Modello parametrico: [scad/bormuri_scheletro.scad](scad/bormuri_scheletro.scad) (OpenSCAD; scegli il pezzo da `PART` e premi F6 + Esporta STL). STL pronti in [stl/](stl/). Immagini: [immagini/assieme_scheletro.png](immagini/assieme_scheletro.png) e [immagini/schema_montaggio_fasi.png](immagini/schema_montaggio_fasi.png).

**Regola di Osvaldo (assoluta): niente tagli e niente fori. Si assembla soltanto.** Tutto quello che segue è scelto per rispettarla: profili e tubi arrivano già tagliati, i fori sono già nei pezzi stampati, i cavi sono già intestati e si collegano a morsetti a leva o a vite.

Le misure segnate **STIMA** vanno confermate sul pezzo vero prima di stampare (si cambia un numero in testa al file .scad e si riesporta).

---

## 1. Controllo severo di fattibilità e compatibilità

Il controllo è stato fatto in tre modi: collisioni calcolate tra tutti i pezzi dell'assieme (volume d'intersezione tra mesh), distanza di ogni pezzo dalla parete interna dell'ottagono, e verifica pezzo per pezzo dell'elettronica del piano contro la regola "niente tagli, niente fori, niente saldature".

**Primo giro: NON superato.** Sono emersi 14 problemi. Tutti quelli meccanici sono stati riprogettati e ricontrollati; per l'elettronica ho sostituito i componenti che richiedono saldature o tagli.

| # | Problema trovato | Gravità | Cosa ho fatto | Stato |
|---|---|---|---|---|
| 1 | Il telaio quadrato da 320 mm del piano **non entrava** nell'ottagono da 40 cm (angolo a 226 mm dal centro, parete a ~197) | Bloccante | Ora la base è da **58 cm** (decisione di Osvaldo, 17:50): telaio **360 mm**, angolo a 255 mm, parete interna a ~287, margine 31 mm | Risolto |
| 2 | Braccio della cassa speaker dentro la spalla Borg | Bloccante | Cassa spostata a x 100 e braccio accorciato | Risolto (0 collisioni) |
| 3 | Nervatura della staffa testa dentro la scheda della camera | Bloccante | Nervatura spostata | Risolto |
| 4 | Piastra frontale della testa che usciva dal guscio della testa in alto (calotta) | Bloccante | Piastra abbassata e ristretta, camera fissata a sinistra e sotto l'occhio | Risolto |
| 15 | Testa vampiro (18/10): il mento più stretto non copriva la parte bassa della piastra | Media | Piastra ristretta in basso a forma di mento (larga 36 mm a z 573); fori maschera spostati in basso ai lati del mento; pareti minime: occhio 3,8 mm, fori 4,3 mm, viti OLED 6,5 mm | Risolto (0 collisioni) |
| 5 | Staffa del guscio sul fianco organico dentro il tronchetto dell'Anker | Bloccante | Staffa spostata di 4 cm in avanti; dal 20/10 è 5 cm avanti per le lamelle del guscio | Superato |
| 6 | Linguette delle staffe dei gusci 1,2 mm dentro la parete inclinata | Media | Linguette arretrate | Risolto |
| 7 | Speaker che sporgeva dal petto, poi cassa che usciva dal fianco del busto in vita | Media | Cassa arretrata di 10 mm; poi spostata verso il centro (centro a x 80, fuori tutto x 54–106) e accorciata (z 401–506, interno 74 mm, 0,18 l), pannello smussato sullo spigolo basso lato Borg; verificata sullo spazio interno del busto (gioco minimo 2,7 mm pannello, 5,8 mm cassa) | Risolto |
| 16 | Proposta 19/10 di spostare lo speaker al centro del petto | Media | Scartata da Osvaldo: lo speaker resta sul lato Borg (`SPK_POS = "borg"`, predefinito); la variante `"centro"` resta nel .scad solo come opzione | Chiuso |
| 17 | Speaker da far rientrare e rimpicciolire (Osvaldo 19/10: "rientra", poi "pessimo") | Media | Cassa lato Borg compatta: faccia quadrata 56 × 56 (x 52–108, z 422–478 reale, centro x 80 / z 450), pannello a y −40, cassa fino a y +10 contro la barra delle spalle; interno 50 × 43 × 50 mm, 4 viti del pannello negli angoli; 0 collisioni | Risolto |
| 18 | Guscio = scultura vampiro originale (20/10): la cornice OLED sporgeva di ~10 mm dal viso | Media | Piastra testa, cornice OLED e camera arretrate di 19 mm (`HEAD_DY = 19`): piastra a y −39…−33, fronte OLED a y −58 (reale), 1,8 mm dietro la parete interna del viso; lente della camera dentro il foro dell'occhio; 0 collisioni | Risolto |
| 19 | Cassa speaker da portare contro il petto della scultura vampiro (Osvaldo 20/10, "Sposta la cassa") | Media | Il petto lì è inclinato (~35° verso il lato Borg, ~34° verso l'alto): cassa e pannello ruotati come la superficie (`SPK_TILT`), pannello centrato sul foro del petto, 1,5 mm dietro la parete interna nel punto più vicino; piastra sulla barra accorciata (sopra z 494 il petto passa a 4 mm dalla barra); 0 collisioni con scheletro e guscio. STL di stampa già raddrizzati | Risolto |
| 20 | Base abbassata a 15 cm perché il guscio combaci al 100% col render v8 (Osvaldo 20/10, "Abbassa a 150") | Media | Ripiano a z 145–150; tutto quello che sta sopra (montante, flange, spalle, testa, speaker) scende di 50 mm; telaio, staffe e vassoio invariati (z 10–30 e 34); montante 510 (ordinato già tagliato). Forme dei pezzi stampati invariate; 0 collisioni | Risolto |
| 21 | Anker tolto dal progetto (Osvaldo 20/10, "Togli Anker") | Media | Tolti tronchetto 100, culla e presa ANKER; la piastra connettori ha solo la USB-C "PC" al centro; la staffa lunga del fianco organico sta 5 cm avanti (reale y −50) per lasciare libere le lamelle di sfogo del guscio al centro del fianco (y 0 ± 35, z 22–102); ripiano invariato a z 145–150. 0 collisioni. Pezzi tolti in tolti_anker/ (`ANKER = true` nel .scad li rimette) | Risolto |
| 22 | Staffa testa che usciva dalla fronte della testa nuova (arrivava a z 613) | Bloccante | Piastra frontale tagliata in alto a z 597, dentro la calotta; il foro maschera in alto a sinistra scende a z 591 | Risolto |
| 23 | Camera: Logitech Brio 300 al posto dell'Arducam, in parte dentro la testa e in parte fuori, in un impianto Borg sull'occhio (Osvaldo 21/10) | Media | Nuovo supporto: piastra di battuta 52 × 50 dietro la camera (y reale −62…−57), 3 gambe avvitate alla piastra frontale, fessura del cavo aperta in basso; asse camera x 24, z 575 come la cavità del guscio. Tolti il supporto Arducam, le viti M2 con molle e il microfono USB (la Brio ce l'ha). 0 collisioni | Risolto |
| 24 | Il guscio vero della base è più stretto e più inclinato di quello previsto (544 in basso e facce a ~14,8°, non 580 e 3,6°): le linguette delle staffe, la cornice della ventola e la piastra connettori uscivano dalla parete fino a 24 mm | Bloccante | Ottagono dello scheletro rifatto sulle misure del guscio vero; linguette delle 7 staffe inclinate come la parete, 1 mm dentro, con le viti perpendicolari alla parete; cornice ventola e piastra connettori sulla faccia inclinata. 0 collisioni con la parete | Risolto |
| 25 | Base aperta sotto (Osvaldo 21/10: fondo approvato) | Media | Fondo ottagonale 5 mm tagliato a laser dal negozio, sotto il telaio (z 5–10), 8 viti M5 nei dadi a T; tolte le 4 piastre a L (le sostituisce il fondo); piedini da 5 mm così l'altezza resta la stessa; 6 feritoie davanti per l'aria che la ventola tira fuori dal retro. La presa della ventola è sul retro e il fondo non la copre | Risolto |
| 26 | Fondo da stampare a casa invece che da ordinare (Osvaldo 21/10) | Media | 9 pezzi da 181 mm al massimo, uniti con 24 farfalle incollate a filo (colla e incastri, come il guscio, niente viti tra i pezzi); ogni taglio passa sotto un profilo del telaio con una vite M5 per lato (24 viti in tutto); le 6 feritoie restano, lontane dai tagli. Rigidità: ogni pezzo è avvitato all'alluminio in 2–4 punti e i tagli sono coperti dai profili, quindi il fondo sostituisce le piastre a L anche stampato. 0 collisioni | Risolto |
| 27 | Testa del guscio abbassata di 65 mm (collo dimezzato, 21/10): lo scheletro della testa la segue | Media | Montante accorciato a 445 (z 30–475); staffa testa, supporto Brio e camera 65 mm più in basso (occhio a z 510); cornice OLED sulla bocca del guscio (z 462, fronte a y reale −77, dietro le labbra); manicotto aperto dietro sotto z 460 per passare sopra barra delle spalle e squadrette. 0 collisioni nello scheletro; contro il guscio la staffa tocca 5 mm³ (trascurabile), cornice OLED e piastra Brio entrano nella pelle del viso dove il guscio le scava già col suo gioco | Risolto (resta da sistemare nel guscio lo spazio della Brio sotto la placca curva) |
| 28 | Occhio e bocca spostati sui punti veri della testa del guscio (21/10 sera) | Media | Asse Brio x 28, z 533, davanti a y reale −100 e retro a −55; cornice OLED x −5, z 478, fronte a y reale −83 (apertura della bocca). Supporto Brio rifatto: piastra di battuta 34 × 38 (y reale −55…−50) su 2 gambe, una per lato della fessura del cavo, avvitate da dietro alla piastra frontale a z 522; la piastra frontale si allarga a destra fino a x 46 per la seconda gamba. 0 collisioni nello scheletro; contro il guscio la staffa tocca 0 mm³, guscio rifatto alle 19:01 con camera e cornice nei punti nuovi: 0 mm³ con tutti i 12 gruppi dello scheletro | Risolto |
| 29 | Base ridotta al minimo compatibile con l'elettronica, busto centrato (Osvaldo 23/10) | Media | Telaio 250 × 250 (prima 360), ventola Noctua NF-A6x25 da 60 (prima 80), ripiano a z 95–100 (base alta 100, prima 150); ottagono 388 tra le facce in basso e 345 in cima (il fondo del busto nuovo, 323 × 268, ci sta senza sbordare). Vassoio 180 × 129 con hub, Plasma e audio; piastra connettori 48 × 48 accanto alla ventola; staffe accorciate; fondo laser rifatto con 8 piedini vicino al bordo (non si ribalta fino a circa 30°, stima). Tutto quello che sta sopra il ripiano scende di 50 mm: va riadattato al busto nuovo quando il guscio dà le posizioni. 0 collisioni (resta il solito contatto di superficie ventola/parete) | Risolto nella base |
| 30 | Scheletro alto rifatto sul busto Flu e base adattata al guscio nuovo (23/10) | Media | Niente colonna: il busto poggia sul ripiano con 4 perni sulle diagonali, 8 mm dentro la pelle (li fa il thread del guscio); una sola flangia (Ø 110) blocca il ripiano al montante. Montante 445 (z 30–475). Barra spalle 320 **davanti** al montante a z 283–303, manicotti delle spalle aperti sotto e smussati (il retro resta libero per lo sportello). Brio (guscio di prova) davanti a (30, y reale −96, z 530), retro a y reale −51,7, asse girato di 10° verso il lato Borg, il guscio fa da sede e il supporto spinge da dietro; piastra frontale della testa a y reale −36..−42; cornice OLED x −15, z 479, smussata ai lati, vetrino 32 × 15 a y reale −107 (3 mm dentro la pelle); speaker x 47,5, z 289, pannello inclinato di 17° come la cupola del petto. Bracci sui nuovi assi (Borg a x−, organico a x+). Base: ventola 60 al centro del retro (z 58) dietro le lamelle; piastra connettori 110 × 52 **dentro** la parete sulla faccia 3 (diagonale dietro lato organico): interruttore, USB-C e jack escono da 3 fori separati del guscio, 4 viti 3 × 8 da fuori; staffe del guscio con viti 3 × 10 **da dentro** nelle torrette Ø 8 del guscio, le 3 lunghe spostate di 55 mm fuori dai pannelli a lamelle (u ±45), 3 corte (tolta quella dietro la piastra). 5 pixel LED da 12 mm nei pulsanti delle facce 1, 5 e 7 del guscio della base, da aggiungere alla catena LED. 0 collisioni tra pezzi (resta il contatto di superficie ventola/parete). Controllo col guscio Flu svuotato (script del thread del guscio): ogni pezzo sopra il ripiano ad almeno 3 mm dalla pelle | Risolto |
| 31 | Prova tecnica dei pezzi interni contro il guscio Flu finale (Osvaldo 26/10: "Il guscio é perfetto in tutto devi fare solo prova tecnica", poi "si" alle 5 modifiche) | Alta | Guscio non toccato. Telaio 240 (con 250 gli angoli toccavano le pareti) e fondo laser rifatto; ventola e cornice 14 mm più dentro; piastra connettori 108 × 50 sagomata sulla parete con 3 viti 3 × 20 (il 4° foro del guscio è cieco); 6 staffe su misura, una per parete, con distanziali per le torrette; barra spalle 1,5 mm più su (z 284,5–304,5); 1–3 mm tolti dove i pezzi erano a meno di 3 mm dalla pelle. Filo luci ripassato nei 5 fori del guscio (R2a schiena, R2b petto, R1a collo, R1b testa, R3a spalla). Esito: busto tutto ad almeno 3 mm, nella base solo i contatti voluti; 0 collisioni tra i pezzi. Da dire al guscio: i fori dei pixel sulle pareti 1 e 7 risultano ~Ø 11,5 e spostati di 1–1,5 mm | Risolto |
| 32 | Minuteria M4 invece di M5 (Osvaldo 29/10: "usa tutto m4 no m5") e profilo Motedis tipo I cava 5 | Bassa | Dadi a T Nut 5 M4, viti M4, squadrette Nut 5. I fori Ø 5,5 dei pezzi stampati e del fondo non cambiano (nessuno STL da rifare): rondella M4 Ø 9 sotto ogni testa. Tubi braccia Ø 10 da Misumi (Motedis non ha il 10 × 10) | Risolto |
| 8 | Inserti filettati a caldo (servono saldatore e mano esperta) | Regola | Tutti sostituiti da **preforo + vite autofilettante 3 mm**: solo cacciavite | Risolto |
| 9 | Profili da tagliare a casa (piano: seghetto e lima) | Regola | **Profili ordinati già tagliati al millimetro** | Risolto |
| 10 | Tubo braccia da 300 mm da tagliare | Regola | 4 tubi Ø 10 **tagliati su misura dal negozio** | Risolto |
| 11 | Elettronica del piano da saldare: 74AHCT125 (chip DIP), WS2812 singoli su PCB, striscia LED da tagliare, GX16 da saldare, PAM8302 con pin da saldare, condensatori/resistenze | Regola | Sostituiti con moduli già cablati (sezione 4), approvati da Osvaldo | Risolto; controllare all'acquisto che ogni pezzo sia davvero "già saldato/cablato" |
| 12 | **Bocca OLED a 30 fotogrammi al secondo su I2C lungo ~60 cm** (dalla base alla testa, passando dal connettore del collo): a 100 kHz servono ~50 ms per schermata, quindi massimo ~20 fps, e il cavo lungo può dare errori | Alta | Bus I2C differenziale **QwiicBus** (due schedine, cavo di rete RJ45 nel collo, solo spine) oppure aggiornare solo le colonne dell'onda; scelta consigliata: QwiicBus | Da provare al banco (fase 1) |
| 13 | Ventola regolata in PWM dal Pico: con il controller senza saldature (sezione 4) non c'è un'uscita libera a morsetto | Bassa | Ventola Noctua 5 V alimentata dal suo cavo USB sull'hub, velocità fissa | Accettato: meno controllo, stessa aria |
| 14 | L'hub USB del piano ha 4 porte, ne servono 6 (camera, microfono, scheda audio, controller, amplificatore, ventola) | Media | Hub USB 2.0 **7 porte alimentato a 5 V** | Risolto |

**Secondo giro (dopo le modifiche): SUPERATO per la parte meccanica.**
- Collisioni tra pezzi veri: **zero**. Restano solo due contatti voluti con i segnaposto (la ventola appoggia sulla griglia inclinata, il magnete dello speaker entra nel foro del pannello).
- Distanza minima dalla parete interna della base da 58 cm: 31 mm per il telaio, 0 mm per cornice ventola e staffe (che devono toccare il guscio).
- Tutti i 15 STL sono solidi chiusi (stampabili), il più grande è 180 × 129 mm (vassoio) e il più lungo 121 mm (staffa lunga): entrano in un piatto da 220 × 220.
- Peso dei pezzi stampati: ~865 cm³ pieni, circa **0,6 kg di PETG** con il 40% di riempimento.

**Restano da verificare con le misure vere** (non sono errori, sono stime):
- camera Logitech Brio 300 senza clip: misurata da Osvaldo (21/10) come tronco di cono, davanti Ø 53, dietro Ø 25, lunga 45 mm; asse x 28, z 533, davanti a y reale −100, retro a −55 contro la piastra del supporto;
- modulo OLED: supposto 38 × 12 × 4,2 con i 4 pin già saldati;
- tubo acrilico della colonna: supposto Ø 150 × 3 mm;
- i gusci (base, busto, testa) li disegna un altro thread: devono avere già i fori per le viti di questi supporti, la zona piatta della bocca (~50 × 26 mm a 77 mm davanti al montante) e l'apertura per lo speaker.

---

## Misure della base (per il guscio)

Base **ridotta** il 23/10 (Osvaldo: misure minime compatibili con l'elettronica, busto centrato): ottagono **388 mm tra le facce in basso** e **345 in cima**, alta **100 mm**. Sopra il ripiano tutte le quote sono quelle delle tavole in viste/ **meno 100 mm** (ripiano a z 100 invece di 200) e vanno riadattate al busto nuovo.

| Parte | Quote (dal tavolo) | Larghezza tra le facce |
|---|---|---|
| 8 piedini in gomma 20 × 5 | 0–5 mm | sotto il fondo, a 165 mm dal centro |
| Fondo ottagonale (un pezzo tagliato a laser) | 5–10 mm | 388, a filo col bordo del guscio |
| Guscio della base (pulsantiere, feritoie, ventola, piastra connettori) | 10–95 mm | 388 in basso, 347 in alto (fuori; facce inclinate di ~13,4°) |
| Ripiano | 95–100 mm | 345 |
| Telaio in alluminio | 10–30 mm | quadrato 240 |
| Ventola 60 (retro, dietro le lamelle) | centro a z 54,8 | x 0, 14 mm più dentro della parete |
| Piastra connettori 108 × 50, dentro la parete (faccia 3, diagonale dietro lato organico), sagomata sulla parete | z 36–86 | interruttore (−97,7, 164,1, 47), USB-C (−156,9, 104,5, 48), jack (−96,0, 156,8, 74); 3 viti 3 × 20 svasate da fuori a (−93,1, 170,9, 40,6), (−163,8, 100,2, 40,6), (−156,9, 93,3, 81,4). Il 4° foro del guscio (−86,2, 164,0, 81,4) è cieco e non si usa |
| Torrette Ø 8 × 8 delle staffe (parete interna) | z 48 e 66, ±6 dal centro della staffa | lunghe a 55 mm dal centro della faccia (reale: Borg y −55, davanti x +55, organica y −55); corte al centro delle diagonali davanti e dietro lato Borg |
| Busto Flu | da z 100 | 4 perni Ø 6 × 8 stampati sul ripiano a (93,7, 93,7), (−98,3, 98,3), (−99,0, −99,0), (96,2, −96,2); nel busto torrette Ø 14 con foro Ø 6,4 (thread del guscio) |

Lato dell'ottagono: ~161 mm in basso, ~143 mm in cima.

## 2. Parti da stampare (STL)

PETG nero opaco, 3 perimetri, 40% di riempimento (le staffe portano peso, i gusci no). Gli STL sono già orientati come nell'assieme e appoggiati sul piano: nel slicer basta "posa su faccia" sulla faccia indicata.

| File STL | Q.tà | Faccia sul piatto | Supporti | Dove va |
|---|---|---|---|---|
| [vassoio_elettronica.stl](stl/vassoio_elettronica.stl) | 1 | Fondo piatto | No | Sopra traversa, mezza spina e lato posteriore del telaio |
| [cornice_ventola.stl](stl/cornice_ventola.stl) | 1 | Griglia | Sì, solo sotto i piedi | Faccia 4 (retro): griglia Borg, ventola tra le due guance |
| [piastra_connettori.stl](stl/piastra_connettori.stl) | 1 | Una faccia | No | Dentro la parete della faccia 3 (diagonale dietro lato organico), dietro i 3 fori delle prese |
| [flangia_ripiano.stl](stl/flangia_ripiano.stl) | 1 | Disco | No | Sul ripiano: lo blocca al montante (2 × M4) e al ripiano (4 viti 3 × 12) |
| [staffa_testa.stl](stl/staffa_testa.stl) | 1 | Dorso della piastra frontale | Sì | Cima del montante: porta bocca e occhio |
| [cornice_oled.stl](stl/cornice_oled.stl) | 1 | Retro | No | Davanti alla staffa testa, l'OLED entra dall'alto |
| [supporto_brio.stl](stl/supporto_brio.stl) | 1 | Piastra (gambe in su) | No | Battuta dietro la Brio 300, su 2 gambe avvitate alla piastra frontale |
| [cassa_speaker.stl](stl/cassa_speaker.stl) | 1 | Fondo (retro) | Sì, sotto il braccio | Davanti alla barra delle spalle, dietro la cupola del petto lato Borg |
| [pannello_speaker.stl](stl/pannello_speaker.stl) | 1 | Piatto | No | Chiude la cassa, lo speaker si avvita davanti |
| [spalla_borg.stl](stl/spalla_borg.stl) | 1 | Faccia superiore del manicotto | Sì | Punta della barra lato x− (braccio Borg teso in avanti) |
| [spalla_organica.stl](stl/spalla_organica.stl) | 1 | Faccia superiore del manicotto | Sì | Punta della barra lato x+ (braccio organico) |
| [gomito_borg.stl](stl/gomito_borg.stl) | 1 | Qualsiasi lato piatto | Sì | Gomito del braccio Borg |
| [gomito_organico.stl](stl/gomito_organico.stl) | 1 | Qualsiasi lato piatto | Sì | Gomito del braccio organico |
| [staffa_base_faccia0.stl](stl/staffa_base_faccia0.stl) | 1 | Fianco (lato lungo) | No | Parete 0 del guscio (base_parete_0), 55 mm fuori dal centro |
| [staffa_base_faccia4.stl](stl/staffa_base_faccia4.stl) | 1 | Fianco (lato lungo) | No | Parete 4 (base_parete_4), 55 mm fuori dal centro |
| [staffa_base_faccia6.stl](stl/staffa_base_faccia6.stl) | 1 | Fianco (lato lungo) | No | Parete 6 (base_parete_6), 55 mm fuori dal centro |
| [staffa_base_faccia1.stl](stl/staffa_base_faccia1.stl) | 1 | Fianco (lato lungo) | No | Diagonale 1 (base_parete_1), al centro |
| [staffa_base_faccia5.stl](stl/staffa_base_faccia5.stl) | 1 | Fianco (lato lungo) | No | Diagonale 5 (base_parete_5), al centro |
| [staffa_base_faccia7.stl](stl/staffa_base_faccia7.stl) | 1 | Fianco (lato lungo) | No | Diagonale 7 (base_parete_7), al centro |

Totale: **19 file, 19 pezzi**. Le 6 staffe sono tutte diverse (26/10): ognuna ha la linguetta alla distanza giusta dalle sue torrette e i distanziali già stampati, quindi va solo sulla parete col suo numero. Le mani (verde e Borg) e i gusci si attaccano ai tubi e ai supporti, ma li disegnano gli altri thread.

---

## 3. Parti meccaniche da comprare (già tagliate, nessun taglio a casa)

### Profilo alluminio 20 × 20 tipo I cava 5 (Motedis, Nut 5, minuteria M4), tagliato su misura dal venditore

Si ordinano dal sito con il servizio di taglio al millimetro (per esempio Motedis o Misumi; entrambi spediscono in Italia). Chiedere testa **squadrata e sbavata**. Nessuna lavorazione (niente filettature in testa): tutto si unisce con squadrette e dadi a T.

| Pezzo | Q.tà | Lunghezza | Dove |
|---|---|---|---|
| Lato davanti / dietro del telaio | 2 | **240 mm** | Base |
| Fianco del telaio | 2 | **200 mm** | Base, tra i due da 240 |
| Traversa centrale | 1 | **200 mm** | Base, da fianco a fianco |
| Mezza spina | 2 | **90 mm** | Base, dalla traversa ai lati davanti e dietro |
| Montante (spina dorsale) | 1 | **445 mm** | Dal piede sulla traversa alla testa (z 30–475, sotto la bocca del busto Flu) |
| Barra delle spalle | 1 | **320 mm** | Davanti al montante, a z 284,5–304,5 |
| **Totale** | **9 pezzi** | **2.025 mm** | |

### Tubi delle braccia, tagliati su misura dal venditore

| Pezzo | Q.tà | Misura | Note |
|---|---|---|---|
| Tubo tondo alluminio Ø 10 × 1 mm | 1 | **124 mm** | Braccio Borg, spalla → gomito |
| Tubo tondo alluminio Ø 10 × 1 mm | 1 | **251 mm** | Braccio Borg, gomito → mano (entra 40 mm nella mano) |
| Tubo tondo alluminio Ø 10 × 1 mm | 1 | **163 mm** | Braccio organico, spalla → gomito |
| Tubo tondo alluminio Ø 10 × 1 mm | 1 | **209 mm** | Braccio organico, gomito → mano |

### Fondo della base

**Scelta di Osvaldo (22/10): un pezzo unico TAGLIATO A LASER da un servizio esterno** (sostituisce i 9 pezzi stampati del 21/10, i cui STL restano in `guscio/join_uni/scena/` come riserva). Scheda completa per il negozio: `taglio_laser/` (file di taglio, disegno quotato, materiale).

| Pezzo | Q.tà | Materiale | File |
|---|---|---|---|
| Fondo ottagonale 388 mm tra le facce (420 tra gli spigoli), 8 fori Ø 5,5 e 4 asole d'aria larghe 8 (davanti) | 1 | Plexiglass (PMMA) **nero** colato 5 mm, oppure compensato di betulla 5 mm | [fondo_base_laser.dxf](taglio_laser/fondo_base_laser.dxf) (anche [.svg](taglio_laser/fondo_base_laser.svg)), mm 1:1. Livello rosso TAGLIO, livello blu INCISIONE (facoltativa: verso di montaggio e posto dei piedini). Disegno quotato: [fondo_base_quotato.svg](taglio_laser/fondo_base_quotato.svg) |

Serve un servizio che tagli lastre di almeno 600 × 600. Taglio totale circa 2,7 m. Prezzo indicativo, **non verificato**: 40–90 € in compensato, 70–150 € in plexiglass nero, spedizione esclusa. Controllo 22/10 sul modello: 0 collisioni con telaio, staffe, vassoio elettronica, cornice ventola, piastra connettori e guscio della base (si toccano solo le facce d'appoggio a z 10); le asole sono fuori dal telaio, sotto il vano davanti, e nessun pezzo le copre.

### Minuteria (tutta M4 per cava 5, stesso venditore dei profili: Motedis 20 × 20 tipo I Nut 5)

Osvaldo 29/10: tutto M4, niente M5. I fori dei pezzi stampati e del fondo restano Ø 5,5: con la vite M4 si mette una rondella piana M4 sotto la testa.

| Pezzo | Q.tà da comprare | Usate | Dove |
|---|---|---|---|
| Squadretta a L 20 Nut 5 con viti e dadi M4 | 30 | 24 | Angoli del telaio 4 + traversa 4 + mezze spine 8 + piede montante 4 + barra spalle 4 |
| Dado a T a martello Nut 5 M4 | 130 | ~80 | Si infilano anche a telaio montato |
| Vite M4 × 8 testa cilindrica (ISO 4762) | 80 | ~48 | Squadrette, se non hanno già le loro viti |
| Vite M4 × 10 testa cilindrica (ISO 4762) | 40 | 15 | Staffe del guscio (6), vassoio (5), cornice ventola (2), staffa testa (2) |
| Vite M4 × 12 testa cilindrica (ISO 4762) | 20 | 8 | Flangia del ripiano (2), cassa speaker (2), spalle (4) |
| Vite M4 × 10 testa bombata (ISO 7380) | 10 | 8 | Fondo tagliato a laser sotto il telaio, nei dadi a T della cava di sotto |
| Rondella piana M4 (DIN 125, Ø 9) | 50 | 31 | Sotto ogni vite M4 che passa in un pezzo stampato o nel fondo |
| Vite autofilettante per plastica 3 × 12 testa bombata | 100 | ~70 | Gusci sulle staffe, griglia ventola, pannello speaker (4 negli angoli), guscio testa, grani di spalle e gomiti |
| Vite autofilettante 3 × 16 | 10 | 7 | Cornice OLED (2) e supporto Brio (2) sulla staffa testa; 3 per la maschera della testa |
| Vite autofilettante 3 × 20 testa svasata | 4 | 3 | Piastra connettori, da fuori attraverso il guscio |
| Vite autofilettante 3 × 10 testa bombata | 30 | 24 | Staffe del guscio, da dentro nelle torrette (4 per staffa) |
| Tappo terminale 20 × 20 | 2 | 2 | Punte barra |
| Clip passacavi a scatto per cava 5 | 10 | 10 | Cavi sul montante |
| Piedino in silicone adesivo Ø 20, alto **5 mm** | 8 | 8 | Sotto il fondo, negli 8 cerchi incisi vicino al bordo |

Attrezzi: solo cacciavite a croce, chiave a brugola da 3 (M4) e 2,5 (M4 bombate), forbici per le fascette.

---

## 4. Elettronica senza saldature

**Approvata da Osvaldo il 17/10/2026** (controller Pimoroni Plasma 2350, tutto senza saldature). Stessa architettura del piano (PC come cervello, niente Raspberry Pi), con i pezzi in versione "solo spine e morsetti". Le voci marcate ⚠ cambiano rispetto al piano.

| # | Componente | Cosa cercare | Si collega con | Note |
|---|---|---|---|---|
| 1 | Camera occhio | **Logitech Brio 300** (microfono integrato) + adattatore USB-C femmina → USB-A maschio | Il suo cavo USB-C fisso, con l'adattatore, nell'hub | Sostituisce l'Arducam (Osvaldo 21/10) |
| 2 | ~~Microfono USB~~ | Tolto: usa quello della Brio 300 (Osvaldo 21/10) | | |
| 3 | ⚠ Controller luci e bocca | **Pimoroni Plasma 2350** (stesso chip RP2350 del Pico 2) | USB-C nell'hub; morsetti a vite per la catena LED; presa Qw/ST per I2C | Sostituisce Pico 2 + 2 × 74AHCT125 + MOSFET: ha già il traslatore di livello 5 V e i morsetti. Il firmware del Pico 2 si porta con poche modifiche ai pin (da dire al thread del codice) |
| 4 | ⚠ OLED bocca | OLED 0,91" 128×32 SSD1306 **con presa STEMMA QT / Qwiic** | Cavo Qwiic | Niente pin da saldare |
| 5 | ⚠ Bus del collo | **SparkFun QwiicBus EndPoint** × 2 + cavo di rete RJ45 corto + accoppiatore RJ45 al collo | Cavi Qwiic e RJ45 | Rende affidabile l'I2C lungo (problema 12) e fa da connettore staccabile del collo per la bocca |
| 6 | ⚠ Sensore temperatura + pulsante nascosto | Sensore Qwiic (es. TMP117) + SparkFun Qwiic Button | Cavi Qwiic in catena | Niente saldature |
| 7 | ⚠ LED della base e dei pulsanti | **Pixel WS2811/WS2812 da 12 mm già cablati** (stringhe da 50, 5 V, spina JST 3 poli), ~130 pixel | Spine JST in catena, inizio sui morsetti del Plasma | Si infilano a pressione in fori da 12 mm nelle celle dei gusci (da dire al thread dei gusci). Niente striscia da tagliare |
| 8 | ⚠ Filo di luci lato Borg | **Filo di luci indirizzabile WS2812 5 V** con spina JST | In fondo alla stessa catena LED | Animabile come gli altri LED, sostituisce MOSFET e PWM |
| 9 | ⚠ LED testa (antenna, parabola) | 3–6 pixel 12 mm già cablati | Catena LED attraverso il collo con spina JST 3 poli | Sostituisce il GX16 da saldare |
| 10 | ⚠ Audio | Scheda audio USB (chiavetta con uscita jack 3,5) + **amplificatore PAM8403 montato** con ingresso jack, morsetti a vite e alimentazione USB | USB nell'hub (2 porte), cavo jack 3,5 | Sostituisce PAM8302 da saldare |
| 11 | ⚠ Speaker | 50 mm 4 Ω 3 W **con cavetti già saldati** | Morsetti a vite dell'amplificatore | |
| 12 | ⚠ Ventola | Noctua NF-A6x25 5V (60 mm) con il suo cavo USB | Porta USB dell'hub (solo alimentazione) | Velocità fissa (problema 13) |
| 13 | ⚠ Hub | Hub USB 2.0 **7 porte**, alimentato con **jack 5 V** | Cavo USB al PC dalla piastra, jack dal 5 V interno | Sceglierne uno che non rimandi corrente verso il PC |
| 14 | Presa sulla piastra | 1 prolunga USB-C maschio/femmina da pannello con viti (PC) | Spina | La presa ANKER è stata tolta con l'Anker |
| 15 | ⚠ Alimentazione | Alimentatore 5 V 10 A con spina 5,5 × 2,5; presa jack da pannello **con fili già saldati**; interruttore da pannello Ø 12 **già cablato**; portafusibile in linea **già cablato** (lama 10 A generale, 5 A linea LED) | **Morsetti a leva Wago 221** | Nessuna saldatura: ogni filo entra in un Wago |
| 16 | Distribuzione 5 V | Wago 221-415 (×6) + cavo di alimentazione con spina jack maschio 5,5 × 2,1 per l'hub + cavetti JST per i LED | Wago | Condensatore 1000 µF 10 V inserito nel Wago all'inizio della catena LED |
| 17 | ~~Anker MagGo A25X1~~ | Tolto dal progetto (Osvaldo 20/10) | | |
| 18 | Fascette, nastro biadesivo in schiuma | | | Fissano hub, Plasma, scheda audio e Wago al vassoio |

**Bilancio di potenza** (5 V 10 A): LED al 40% ~3 A, hub con camera Brio e audio ~0,7 A, amplificatore ~0,6 A di picco, ventola 0,1 A, controller 0,05 A. Totale **~4,5 A**, margine oltre il doppio.

### Cavi e luci nel modello (23/10)

Osvaldo: "mancano tutti i cavi e luci". Ora il modello ha i percorsi veri dei cavi. Tutti i cavi sono comprati **già intestati**: niente da tagliare, spellare o saldare.

**Percorsi:**
- I cavi salgono sui due fianchi del montante: x+ per Brio e speaker, x− per QwiicBus e linea LED.
- Sono tenuti da 10 clip a scatto per la cava, 5 per fianco, a z 140, 200, 250, 340 e 400.
- Passano nei fori Ø 18 dietro della flangia e del ripiano.

| Cavo | Da → a | Percorso | Cosa comprare |
|---|---|---|---|
| USB della Brio 300 | camera → hub | ~53 cm | Il suo cavo fisso (1,5 m): l'avanzo si arrotola con una fascetta sul vassoio |
| Speaker | cassa → amplificatore | ~36 cm | Speaker 50 mm con spina JST PH 2 poli + prolunga JST PH 2 poli 50 cm con un capo stagnato (va nei morsetti dell'amplificatore) |
| OLED | modulo → QwiicBus della testa | ~12 cm | Cavo Qwiic 100 mm. Esce in basso dietro la cornice e passa sotto il piatto della staffa testa |
| Bus del collo | QwiicBus testa → QwiicBus base | ~44 cm | Cavo di rete RJ45 piatto 50 cm. I 2 QwiicBus EndPoint si attaccano col biadesivo: in testa sul fianco x− del manicotto, nella base sul vassoio |
| Pixel della base | Plasma → 5 pixel delle facce 1, 5, 7 | ~70 cm | 5 pixel WS2811 12 mm singoli con spine JST SM 3 poli + 5 prolunghe JST SM 3 poli 20 cm |
| Linea LED verso le luci del busto | ultimo pixel della base → foro R2a (schiena) | ~50 cm dentro, lungo il montante | Prolunga JST SM 3 poli 60 cm |
| Filo di luci (26/10) | R2a schiena → tubo fuori → R2b petto → dentro → R1a collo → tubo → R1b testa → dentro giù per il collo → R3a spalla → tubo lungo il braccio → R3b polso | dentro: ~10 cm (petto→collo) + ~38 cm (testa→spalla); fuori: i tre tratti nei tubi trasparenti | Filo WS2812 con spina JST SM: la lunghezza totale la dà il thread del pacchetto finale (tubi fuori) |
| USB-C del PC | piastra connettori → hub | ~15 cm | Prolunga USB-C da pannello già cablata |
| Jack 5 V e interruttore | piastra connettori → Wago | ~20 cm | Presa jack e interruttore da pannello già cablati (sezione 4) |
| Ventola | ventola → hub | ~11 cm | Il suo cavo USB |

**Luci:**
- I 5 pixel da 12 mm della base stanno nei fori Ø 12,2 del guscio sulle facce 1, 5 e 7, spinti da dentro.
- La battuta per i pixel la mette il thread del guscio sulla parete interna.

- Il filo di luci entra ed esce dal guscio nei 6 fori Ø 9,4 con boccola (thread del pacchetto finale): dentro passa a 3 mm o più dalla pelle, sul fianco del montante e dietro il collo.
- I tubi esterni (trasparenti da 9 mm e corrugati) li disegna e conta il thread del pacchetto finale.

| Minuteria in più | Q.tà |
|---|---|
| Clip passacavi a scatto per profilo 2020 cava 6 | 10 |
| Nastro biadesivo in schiuma (già in lista) | per i 2 QwiicBus |

### Schema di collegamento

```
 PIASTRA CONNETTORI (retro)                     DENTRO LA BASE (vassoio)
 ┌──────────────┬──────────────┐
 │        USB-C "PC"         │
 │      │       │              │
 │ jack 5V      │ interruttore │
 └──┬───┴───────┴──────┬───────┘
    │ USB dati          │ 5 V 10 A
    ▼                   ▼
 HUB USB 7 porte ◄── jack ── Wago 5 V ── fusibile 10 A ── interruttore ── jack 5 V
   ├─ camera Brio 300 con microfono ── (cavo USB-C della camera + adattatore USB-A)
   ├─ scheda audio ── jack 3,5 ── amplificatore PAM8403 ── speaker petto
   ├─ alimentazione amplificatore (USB)
   ├─ ventola Noctua (USB)
   └─ Plasma 2350 (USB-C)
         ├─ morsetti LED ◄── Wago 5 V ── fusibile 5 A
         │     └─ pixel base ─► pixel pulsanti ─► (JST al collo) ─► pixel testa ─► filo di luci Borg
         └─ Qw/ST ─ sensore temperatura ─ pulsante nascosto ─ QwiicBus ══RJ45 al collo══ QwiicBus ─ OLED bocca
```

---

## 5. Montaggio passo per passo

Vedi [immagini/schema_montaggio_fasi.png](immagini/schema_montaggio_fasi.png). Prima di chiudere ogni fase, provare che tutto scorra e stringere solo alla fine.

1. **Telaio della base.** Posa i due 240 (davanti e dietro) e i due 200 (fianchi) in quadrato, con i 200 tra i 240. Un dado a T e una squadretta in ogni angolo interno. Infila la traversa 200 al centro (da fianco a fianco) e le due mezze spine 90 (dalla traversa ai lati davanti e dietro), una squadretta per lato a ogni giunto. Infila 8 dadi a T nella cava di sotto: 2 in ognuno dei 4 profili esterni, a 8 cm dal centro. Controlla che il quadrato sia in piano sul tavolo.
1b. **Fondo (tagliato a laser).** Posa il fondo sul tavolo con la faccia incisa SOTTO e le asole verso il davanti. Posa sopra il telaio, allinea gli 8 fori agli 8 dadi a T della cava di sotto e avvita da sotto le 8 viti M4 × 10 a testa bombata con rondella. Gira il tutto e incolla gli 8 piedini 20 × 5 negli 8 cerchi incisi, vicino al bordo. Il bordo del guscio della base, alla fine, appoggia sul fondo, a filo.
2. **Staffe.** Avvita le 6 staffe sul telaio (1 × M4 ciascuna nell'asola del piede, dado a T nella cava di fuori): ogni staffa ha il numero della sua parete nel nome del file, la 0, 4 e 6 a 55 mm dal centro della faccia, la 1, 5 e 7 al centro delle diagonali. Sulla diagonale 3 non va la staffa: lì c'è la piastra connettori. Il guscio si avvita poi da dentro: 4 viti 3 × 10 per staffa nelle torrette del guscio, i distanziali sono già stampati.
3. **Elettronica della base.** Avvita il vassoio (5 × M4: traversa, mezza spina, lato posteriore). Fissa con fascette hub, Plasma, scheda audio, amplificatore e i Wago nelle zone incise. Infila la ventola tra le guance della cornice e appoggia i piedi della cornice sul lato posteriore del telaio (2 × M4): la ventola sta al centro del retro, dietro le lamelle. La piastra connettori si appoggia da dentro alla parete 3 (è sagomata come la parete) e si avvita da fuori con 3 viti 3 × 20 svasate; interruttore e jack si stringono con il loro dado sulla parete, l'USB-C con 2 viti nella tasca della piastra. Collega tutto secondo lo schema della sezione 4, con i cavi verso la piastra fermati al pettine del vassoio.
4. **Montante.** Metti in piedi il profilo da 445 al centro, sopra l'incrocio tra traversa e mezze spine, con 4 squadrette (due sulla traversa, due sulle mezze spine). Controlla la verticale con una livella sui due lati.
5. **Ripiano.** Infila il ripiano (guscio) dall'alto del montante, poi la flangia con il disco in basso: si blocca al montante con 2 × M4 e al ripiano con 4 viti 3 × 12. I cavi salgono nel busto dai 4 fori della flangia.
6. **Barra delle spalle e speaker.** Avvita la barra 320 davanti al montante a z 284,5–304,5 (4 squadrette). Avvita la cassa speaker alla faccia anteriore della barra (2 × M4, il cacciavite passa dall'interno della cassa), poi chiudi con il pannello e lo speaker davanti.
7. **Testa.** Infila la staffa testa sulla cima del montante e bloccala (2 × M4 sui fianchi). Infila l'OLED dall'alto nella cornice, avvita la cornice alla piastra (2 viti 3 × 16). Avvita il supporto Brio alla piastra frontale con 2 viti 3 × 16 da dietro. La Brio 300 entra nell'impianto Borg del guscio e il supporto la tiene da dietro: infila il suo cavo nella fessura del supporto, aperta in basso.
8. **Braccia.** Calza le spalle sulle punte della barra (2 × M4 ciascuna dall'alto). Infila i tubi corti tra spalle e gomiti, i tubi lunghi dai gomiti verso le mani, e blocca ogni tubo con la vite autofilettante laterale. Poi si montano i gusci di busto, braccia, mani e testa (thread dei gusci).

Prova finale (dal piano): inclinare Bormuri di 30° e lasciarlo; deve tornare giù da solo.

---

## 6. Cose da comunicare agli altri thread

- **Piano**: base ridotta (23/10) 388/345 tra le facce, alta 10 cm, telaio **240 mm**, ventola 60, montante 445, niente Anker (tolto il 20/10). Lista di taglio aggiornata alla sezione 3.
- **Gusci**: servono già nei pezzi stampati i fori per le viti delle staffe (4 per staffa), la piastra connettori, la griglia ventola, la zona piatta della bocca, il foro dell'occhio e i fori da 12 mm per i pixel LED.
- **Codice**: il controller diventa un Pimoroni Plasma 2350 (RP2350 come il Pico 2): catena LED unica, OLED e sensori su Qw/ST, ventola senza PWM.
